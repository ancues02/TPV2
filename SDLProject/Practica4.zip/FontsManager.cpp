#include "FontsManager.h"

FontsManager::FontsManager() {
}

FontsManager::~FontsManager() {
}

